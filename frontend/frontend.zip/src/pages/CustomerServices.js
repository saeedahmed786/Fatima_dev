import React from 'react'

export const CustomerServices = () => {
    return (
        <div className='text-center pt-5'>
            <h4>Customer Services</h4>
        </div>
    )
}
