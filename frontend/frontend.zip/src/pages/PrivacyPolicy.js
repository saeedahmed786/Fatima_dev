import React from 'react'

export const PrivacyPolicy = () => {
    return (
       <div className='text-center pt-5'>
        <h4>Privacy Policy</h4>
       </div>
    )
}
