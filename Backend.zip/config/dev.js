module.exports = {
    JwtSecret: 'kdjkasjqr8239r8kfj9390239tfkeit049igkjkvjvw049t09tofjkwrjt034tigdfkjgkdfjg0rt9304fsdkfj04t904gigo',
    GoogleClient: "971744690757-7bofg1rqslqvst1glaspi5o9li7le07k.apps.googleusercontent.com"
}