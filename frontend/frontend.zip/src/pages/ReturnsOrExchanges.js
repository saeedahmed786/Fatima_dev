import React from 'react'

export const ReturnsOrExchanges = () => {
    return (
        <div className='text-center pt-5'>
            <h4>Returns/Exchanges</h4>
        </div>
    )
}
