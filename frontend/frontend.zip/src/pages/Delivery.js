import React from 'react'

export const Delivery = () => {
    return (
        <div className='text-center pt-5'>
            <h4>Delivery</h4>
        </div>
    )
}
