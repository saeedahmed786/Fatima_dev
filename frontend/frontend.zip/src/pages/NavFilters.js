import React from 'react'

export const NavFilters = (props) => {
    const query = new URLSearchParams(props.location.search);
    return (
        <div>
            
        </div>
    )
}
