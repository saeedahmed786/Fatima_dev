import React from "react";

const Payment = () => {
  return (
    <div className="container p-5 text-center">
      <p>Complete your purchase</p>
    </div>
  );
};

export default Payment;